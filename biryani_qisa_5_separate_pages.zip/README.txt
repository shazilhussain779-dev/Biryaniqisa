Biryani Qisa multi-page website

Open index.html for the Home page. Navigation links open separate files: menu.html, story.html, gallery.html, contact.html. Upload all HTML files together to the same hosting folder.
